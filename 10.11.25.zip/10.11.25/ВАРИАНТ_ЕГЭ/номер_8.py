from itertools import product

n = 0

for i in product(sorted('ТЕОРИЯ'), repeat = 6):
    a = ''.join(i)
    n += 1
    if n % 2 != 0 and a[0] not in 'РТЯ' and a.count('И') >= 2:
        print(a, n)