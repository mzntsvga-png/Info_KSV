#1
'''
from itertools import product
letters = list('СТРОКА')
letters.sort()

ans = 0
for i, w in enumerate(product(letters, repeat=5), 1):
    if i % 2 == 0 and w[0] not in 'АСТ' and w.count('О') == 2:
        ans = i

print(ans)
'''
#2
'''
import itertools

even = {'0','2','4'}
count = 0
for s in itertools.product('01234', repeat=9):
    if s[0] == '0':
        continue
    bad = any(s[i] in even and s[i+1] in even and s[i+2] in even for i in range(7))
    if bad:
        continue
    adj = sum(1 for i in range(8) if s[i] in even and s[i+1] in even)
    if adj == 2:
        count += 1

print(count) 
'''
'''
#3

import itertools

even = {'0','2','4','6'}
count = 0
for s in itertools.product('0123456', repeat=5):
    if s[0] == '0':
        continue
    if any(s[i] in even and s[i+1] in even and s[i+2] in even for i in range(3)):
        continue
    adj = sum(1 for i in range(4) if s[i] in even and s[i+1] in even)
    if adj >= 2:
        count += 1

print(count) 
'''
'''
#4

count = 0

odd = {1, 3, 5, 7, 9, 11}      
even = {0, 2, 4, 6, 8, 10}   

def is_valid(num):
    bad = 0
    for i in range(4):
        if num[i] in odd and num[i+1] in odd:
            bad += 1
    return bad <= 2

for a in range(1, 12):          
    for b in range(12):
        for c in range(12):
            for d in range(12):
                for e in range(12):
                    digits = [a, b, c, d, e]
                    if is_valid(digits):
                        count += 1

print(count)
'''
'''
#5
def is_valid(n):
    s = str(n)
    for i in range(len(s)-1):
        if (int(s[i]) % 2) == (int(s[i+1]) % 2):
            return False
    return True

last_index = None
for idx, num in enumerate(range(10000, 100000), start=1):
    if is_valid(num) and idx % 15 == 0:
        last_index = idx

if last_index is not None:
    print(last_index)
'''

#6
ans = 0
for a in range(1, 16):
    for b in range(16):
        for c in range(16):
            for d in range(16):
                for e in range(16):
                    for f in range(16):
                        num_16 = a * 16**6 + b * 16**5 + c * 16**4 + d * 16**3 + 10 * 16**2 + e * 16**1 + f * 16**0
                        s = num_16 
                        num_8 = []
                        while s > 0:
                            num_8.append(s % 8)
                            s //= 8
                        if len(num_8) == 9 and num_8[4] == 2 and num_8[0] == 3:
                            ans += 1

print(ans)           
